"""
1)Read in your poem (the file poem.txt)
 - read each line of the poem into a list
2)reverse the poem
 - by running the list backward (look up range and how this can be done, you can use a while loop if you prefer)
3) Write the poem back to disk and save it to your docs folder in poem2.txt
4) Read your poem, poem2.txt, in again (by calling the function you wrote earlier)
5) now append to the poem the reason why this is your favorite song or poem and your name, saving the result in poem2.txt
 - The result should be your poem, the reason you like this poem or song, and your name.
"""

import os

# setting both paths
poem_path = os.path.join("docs", "poem.txt")
new_poem_path = os.path.join("docs", "poem2.txt")
# creating empty lists for poem lines
lines_list = []
reversed_lines_list = []
blank_list = []

def read_to_list(path, poem_list):
    """Reads a poem into a list of lines """
    with open(path, "r") as f: # opening the file in read mode
        for line in f:
            print(line)
            line = line.strip() # getting rid of newlines
            poem_list.append(line) # adding each line to the list
    return poem_list


def reversed_list(given_list, new_list):
    """ Reverses a given list and returns it as a new list"""
    for i in reversed(given_list): # running the poem reversed in a loop
        new_list.append(i) # adding each line to a new list
    return new_list


def write_list_in_file(path, poem_list):
    """Writes a poem into a file """
    with open(path, "w") as f: # writing the reversed list in new file
        for i in poem_list:
            f.write(i)
            f.write("\n")


def append_text(path, text):
    """Appends text to a file """
    with open(path, "a") as f: # appending the required text to the file
        f.write(text)


def main():
    right_way_poem_list  = read_to_list(poem_path, lines_list) # adding each line to a list
    reversed_poem_list = reversed_list(right_way_poem_list, reversed_lines_list) # this list is reversed
    write_list_in_file(new_poem_path, reversed_poem_list)
    print()
    print("Reversed poem:")
    read_to_list(new_poem_path, reversed_poem_list)
    append_text(new_poem_path, "This is my favorite poem because it describes life's journeys \n Anita Soffer")


if __name__ == "__main__":
    main()



