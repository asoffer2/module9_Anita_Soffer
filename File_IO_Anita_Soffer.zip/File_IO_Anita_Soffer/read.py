
# This file contains all the functions that read files


def read_file(path, file_list):
    """ Reads a file into an empty list and prints
        the file line by line on the screen. Each item in
        the list is one line of the file."""
    try: # validate
        with open(path, "r") as f: # opens in read mode
            for line in f:
                line = line.strip().replace("\n", "") # removes whitespace and newlines
                file_list.append(line) # adds each line to a list
                print(line, end="\n") # prints to the screen line by line
        return file_list
    except FileNotFoundError as f: # accepts error gracefully
        print("File not found", f)
        return ""


def read_and_print(path):
    """ Reads a file and prints it"""
    try: # validate
        with open(path, "r") as f: # opens in read mode
            for line in f:
                line = line.strip().replace("\n", "") # removes whitespace and newlines
                print(line, end="\n") # prints to the screen line by line
    except FileNotFoundError as f: # accepts error gracefully
        print("File not found", f)
        return ""


def just_read(path):
    """Reads a file without printing it"""
    try: # validate
        with open(path, "r") as f:
            for _ in f:
                f.readline() # reads each line
    except FileNotFoundError as f: # accepts error gracefully
        print("File not found", f)
        return ""


