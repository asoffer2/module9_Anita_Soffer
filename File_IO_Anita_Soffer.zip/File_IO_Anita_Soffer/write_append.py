
# This file contains the functions which write/append


def write_in(path, writing_list):
    """Writes a list into a file"""
    try: # validate
        with open(path, "w") as f: # opens in write mode
            for line in writing_list:
                f.write(line + "\n") # writes each line into the file on a new line
    except FileNotFoundError as f: # accepts errors gracefully
        print("File not found", f)
        return ""


def append_to_file(path, text: str):
    """Appends given text to a file"""
    try: # validate
        with open(path, "a") as f: # opens in append mode - does not delete prior text
            f.write(text)
    except FileNotFoundError as f: # accepts errors gracefully
        print("File not found", f)
        return ""