
# This file contains the function which rearranges text


def reverse(poem_list, revised_list):
    """Reversed a list and replaces all instances of the
       word 'I' for 'you', appending the new lines to a new
       list. """
    for index,item in enumerate(reversed(poem_list)): # runs the list backwards which reverses the order
        revised_list.append(item) # adds the item in reversed order
        # replace ll variations of "I" with "you"
        if " I " in item:
            revised_list[index] = item.replace("I", "you")
        elif "I " in item:
            revised_list[index] = item.replace("I", "you")
        elif " I," in item:
            revised_list[index] = item.replace("I", "you")
    return revised_list










