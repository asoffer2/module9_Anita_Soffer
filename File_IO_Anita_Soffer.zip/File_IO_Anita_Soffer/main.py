"""This file contains the main area which imports all
    the functions and facilitates a program which:
    1) Reads a file and adds each line to a list while printing it on the screen
    2) reverses the order of the list and replaces each instance of "I" with "meatball"
    3)Writes the new poem to a new file """

# imports
import os
from read import read_file,read_and_print,just_read
from rearrange import reverse
from write_append import write_in,append_to_file

DOCS_PATH = "docs" # setup constant path
poem_path = os.path.join(DOCS_PATH, "poem_original.txt") # join original poem path
revised_poem_path = os.path.join(DOCS_PATH, "poem_remix.txt") # join revised poem path

# setup empty lists
poem_list = []
revised_list = []


def main():
    """Main function: pulls together functions to read, rearrange, write, and append
       a text file"""
    read_file(poem_path, poem_list) # reads the file into a list
    # reverses the text in the list and replaces 'I' with 'you', appending the new text to a new list
    reverse(poem_list, revised_list)
    write_in(revised_poem_path, revised_list) # writes the new list into a new file
    # visual separation
    print()
    print("Revised:")
    read_and_print(revised_poem_path) # prints the revised poem in read mode
    just_read(revised_poem_path) # reads the revised poem in
    # appends new text to the new file
    append_to_file(revised_poem_path, "--- \n Remixed by: Anita Soffer \n I changed the word 'I' to 'you' and reversed the lines")


if __name__=="__main__":
    main()


